# -*- coding: utf-8 -*-
"""
Created on Fri Dec 15 15:26:16 2017

@author: User
"""
import pandas as pd
import pyodbc
import datetime
from math import sin, radians, atan2, cos, sqrt
import time


def help():
    print('Functions that assist in the processing and transformation of data')
    print('\n')
    print('1) Divide track(data, track_number=1), the second parameter is\
 responsible for the number of the trip that is needed (separates\
 this trip). This function selects the desired trip from\
 the entire set of data and writes it into a separate table.\n' )
    print('2) Identification of the number of trips in the data set\n')
    print('3) Determines the track numbers\n')
    print('4) Checking connection to SQL SERVER')
    print('5)')
    print('6)')


def divide_track(df, n=1):
    track_number = 1
    if n > number_of_tracks(df):
        print('Track number is too large. There is only', number_of_tracks(df)\
              ,'tracks. Pay attention to parameters of the function.')
        print()
        raise Exception('Second parameter is wrong.')
    id = df['IncomingTrackId'][0]
    df_temp = pd.DataFrame()
    index_start = -1
    index_end = 0
    ar = []
    for i in range(len(df['IncomingTrackId'])):
        if id == df['IncomingTrackId'][i]:
            if track_number == n:
                if index_start == -1:
                    index_start = i
        else:
            if index_start != -1 and not index_end:
                index_end = i
            track_number += 1
            id = df['IncomingTrackId'][i]
    if index_start != -1 and not index_end:
        index_end = i
    df_temp = df.iloc[index_start:index_end].copy()
    for i in range(len(df_temp)):
        ar.append(i)
    df_temp.index = ar
    df_temp.sort_values('Number', inplace=True)
    return df_temp.reset_index(drop=True)


def divide_rtrack(df, n=1):
    track_number = 1
    if n > number_of_rtracks(df):
        print('Track number is too large. There is only', number_of_rtracks(df)\
              ,'tracks. Pay attention to parameters of the function.')
        print()
        raise Exception('Second parameter is wrong.')
    id = df['RichTrackId'][0]
    df_temp = pd.DataFrame()
    index_start = -1
    index_end = 0
    ar = []
    for i in range(len(df['RichTrackId'])):
        if id == df['RichTrackId'][i]:
            if track_number == n:
                if index_start == -1:
                    index_start = i
        else:
            if index_start != -1 and not index_end:
                index_end = i
            track_number += 1
            id = df['RichTrackId'][i]
    if index_start != -1 and not index_end:
        index_end = i
    df_temp = df.iloc[index_start:index_end].copy()
    for i in range(len(df_temp)):
        ar.append(i)
    df_temp.index = ar
    df_temp.sort_values('Number', inplace=True)
    return df_temp.reset_index(drop=True)


def timer(number):
    for i in range(60 * number + 1):
        print(i // 60, ':', i % 60)
        time.sleep(1)


def reverse_timer(number):
    for i in range(60 * number, 0, -1):
        print(i // 60, ':', i % 60)
        time.sleep(1)


def number_of_tracks(df):
    number = 1
    id = df['IncomingTrackId'][0]
    for i in range(len(df['IncomingTrackId'])):
        if id != df['IncomingTrackId'][i]:
            number += 1
            id = df['IncomingTrackId'][i]
    return number


def number_of_rtracks(df):
    number = 1
    id = df['RichTrackId'][0]
    for i in range(len(df['RichTrackId'])):
        if id != df['RichTrackId'][i]:
            number += 1
            id = df['RichTrackId'][i]
    return number


def tracks(df):
    ar = [df['IncomingTrackId'][0]]
    id = df['IncomingTrackId'][0]
    for i in range(len(df['IncomingTrackId'])):
        if id != df['IncomingTrackId'][i]:
            ar.append(df['IncomingTrackId'][i])
            id = df['IncomingTrackId'][i]
    return ar


def check_conn():
    conn = pyodbc.connect(
                'DRIVER={SQL Server};'
                'SERVER=RAXEL-ab-sql;'
                'DATABASE=MobileServiceIncoming;'
                'Trusted_Connection=no;'
                'UID=report;'
                'PWD=report963;'
                )
    sql = """
        SELECT top 5 *
        FROM [MobileServiceIncoming].[dbo].[RaxelMachineLearningResults]
        """
    return pd.read_sql(sql, conn)


def change_date(df, name):
    date = []
    for i in range(len(df[name])):
        s = df[name][i]
        f = s[:26]
        dt = datetime.datetime.strptime(f, '%Y-%m-%d %H:%M:%S.%f')
        date.append(dt)
    date_dif = []
    for i in range(1, len(date)):
        date_dif.append(date[i] - date[i-1])
    dataframe = pd.DataFrame(data = date, columns = ['Date'])
    return dataframe.Date.diff().fillna(0)


def numpy_date(df, name):
    date = []
    for i in range(len(df[name])):
        s = str(df[name][i])
        f = s[:26]
        date.append(datetime.datetime.strptime(f,'%Y-%m-%d %H:%M:%S.%f'))
    dataframe = pd.DataFrame(data = date, columns = ['Date'])
    df[name] = dataframe['Date'].copy()
    return df


def distance(ar1, ar2):
    lat1, lon1, lat2, lon2 = ar1[0], ar1[1], ar2[0], ar2[1]
    lon1, lat1, lon2, lat2 = map(radians, [lon1, lat1, lon2, lat2])
    dlon = lon2 - lon1
    dlat = lat2 - lat1
    a = sin(dlat/2)**2 + cos(lat1) * cos(lat2) * sin(dlon/2)**2
    c = 2 * atan2(sqrt(a), sqrt(1-a))
    return 6371 * c


def invest(investment, years, percent):
    result = investment
    convert = percent / 100
    for i in range(years):
        result = result * (1 + convert)
    return result


def delete_outliners(dataframe):
    df = dataframe.copy()
    df.sort_values('PointDate', inplace=True)
    df.drop_duplicates(['Latitude', 'Longitude'], keep='last', inplace=True)
    df.drop_duplicates(['PointDate'], keep='last', inplace=True)
    df.reset_index(inplace=True)
    return df


def get_info_track(df):
    conn = pyodbc.connect(
                'DRIVER={SQL Server};'
                'SERVER=RAXEL-ab-sql;'
                'DATABASE=MobileServiceStage;'
                'Trusted_Connection=no;'
                'UID=report;'
                'PWD=report963;'
                )
    IncId = df['IncomingTrackId'][0]
#   поиск поездки(rich_track) по id
    tr_id = '''
        SELECT *
        FROM [MobileServiceStage].[dbo].[RichTracks]
        where IncomingTrackId = ?
    '''
    track_info = pd.read_sql(tr_id, conn, params = [int(IncId)])
    return track_info


def right_fusion(df1, df2):
    df = pd.DataFrame()
    df = df1.copy()
    k = len(df1.columns)
    for i in df2.columns:
        df.insert(loc = k, column = i, value = df2[i])
        k += 1
    return df


def tracks_info_into_frame(cluster):
    cluster.sort_values(by=['IncomingTrackId'])
    df = get_info_track(divide_track(cluster))
    for i in range(1, number_of_tracks(cluster)):
        df_temp = get_info_track(divide_track(cluster, i + 1))
        df = pd.concat([df, df_temp], ignore_index=True)
    print(df)


def fuse_data_into_csv():
    df1 = pd.read_csv(r'E:\Arsen\TokioMarine\bind_ss_week1.txt')
    df2 = pd.read_csv(r'E:\Arsen\TokioMarine\bind_ss_week2.txt')
    df3 = pd.read_csv(r'E:\Arsen\TokioMarine\bind_ss_week3.txt')
    df4 = pd.read_csv(r'E:\Arsen\TokioMarine\bind_ss_week4.txt')
    df5 = pd.read_csv(r'E:\Arsen\TokioMarine\bind_ss_week5.txt')
    df6 = pd.read_csv(r'E:\Arsen\TokioMarine\bind_ss_week6.txt')
    df = pd.concat([df1, df2, df3, df4, df5, df6], ignore_index=True)
    return df


#def box(n):
#    print(' ', end='')
#    for i in range(n):
#        print('_', end='')
#    print('')
#    print('/', end='')
#    for i in range(n-1):
#        print(' ', end='')
#    print('/\ \n', end='')
#    for i in range(n):
#        print('‾', end='')


def get_data_and_create_csv():
    inc_points = pd.read_csv(r'E:\Arsen\скрипты\2trips.csv')
    inc_points = divide_track(inc_points[1:].reset_index(drop=True))
    dt = inc_points.DeviceToken[0]
    qtracks = '''
        SELECT *
        FROM [MobileServiceStage].[dbo].[RichTracks] (nolock)
        where [DeviceToken] = ? 
    '''
    rich_tracks = pd.read_sql(qtracks, conn, params=[dt])
    qpoints = '''
        SELECT *
        FROM [MobileServiceStage].[dbo].[RichTrackPoints] (nolock)
        where [DeviceToken] = ?
    '''
    rich_points = pd.read_sql(qpoints, conn, params=[dt])
    qdet = '''
        SELECT *
        FROM [MobileServiceStage].[dbo].[RichTrackDetails] (nolock)
        where [DeviceToken] = ?
    '''
    rich_details = pd.read_sql(qdet, conn , params=[dt])

    inc_points.to_csv("inc_points.csv", encoding='utf-8')
    rich_tracks.to_csv("rich_tracks.csv", encoding='utf-8')
    rich_points.to_csv("rich_points.csv", encoding='utf-8')
    rich_details.to_csv("rich_details.csv", encoding='utf-8')


def divide_df(df):
    use_cols1 = ['IncomingTrackId','Number','TotalMeters','Speed','MidSpeed','PointDate','TickDate','Latitude',
                'Longitude','Height','Course','Yaw','Lateral','Acceleration','Deceleration','EstablishedIndexA',
                'EstablishedIndexB','TickTimestamp','AccelerationX','AccelerationY','AccelerationZ','GyroscopeX','GyroscopeY',
                'GyroscopeZ','AccelerationXOriginal','AccelerationYOriginal','AccelerationZOriginal','GyroscopeXOriginal',
                'GyroscopeYOriginal','GyroscopeZOriginal','DeviceToken']
    use_cols2 = [	'Id2','TrackToken2','DeviceToken2','IncomingTrackId2','StartDate2','EndDate2','Distance2','Duration2',
                 'AccelerationCount2','DecelerationCount2','Rating2','PhoneUsage2','TrackOrigin2','OriginChanged2','AddressStart2',
                 'AddressFinish2','DistanceGPS2','Urban2','Region2','Country2','RatingOverSpeed2','RatingAcceleration2',
                 'RatingTimeOfDay2','RatingPhoneUsage2','OverSpeedMileage2','MidOverSpeedMileage2','HighOverSpeedMileage2',
                 'CompanyId2','RushHours2','NightHours2','DailyHours2','RatingDeceleration2','KOverSpeed2','KAcceleration2',
                 'KTimeOfDay2','KDeceleration2','MaxSpeed2','AverageSpeed2','PhoneUsageOverSpeed2','PhoneUsageKm2',
                 'PhoneUsageOverSpeedKm2','KPhoneUsage2']
    df1 = df[use_cols1]
    df2 = df[use_cols2]
    df1 = df1.dropna(how='any').reset_index(drop=True)
    df2 = df2.dropna(how='any').reset_index(drop=True)
    df2.columns = ['Id','TrackToken','DeviceToken','IncomingTrackId','StartDate','EndDate','Distance','Duration',
                 'AccelerationCount','DecelerationCount','Rating','PhoneUsage','TrackOrigin','OriginChanged','AddressStart',
                 'AddressFinish','DistanceGPS','Urban','Region','Country','RatingOverSpeed','RatingAcceleration',
                 'RatingTimeOfDay','RatingPhoneUsage','OverSpeedMileage','MidOverSpeedMileage','HighOverSpeedMileage',
                 'CompanyId','RushHours','NightHours','DailyHours','RatingDeceleration','KOverSpeed','KAcceleration',
                 'KTimeOfDay','KDeceleration','MaxSpeed','AverageSpeed','PhoneUsageOverSpeed','PhoneUsageKm',
                 'PhoneUsageOverSpeedKm','KPhoneUsage']
    return df1, df2


def country_eng(df):
    coun = pd.read_excel(r'E:\Arsen\Driver Signature\data_for_poi\countries.xlsx')
    temp = df.Country.copy()
    for i in range(len(temp)):
        nn = coun.loc[coun.name == temp[i]].reset_index(drop=True)
        temp[i] = nn.name_eng[0]
    df.Country = temp.copy()
    return df


def unique_values(df, name):
     return list(set(list(df[name])))


#def grid(n):
#    for i in range(2*n + 3):
#        for j in range(2*n + 3):
#            if i in (0, n + 1, 2*n + 2):
#                if j in (0, n + 1, 2*n + 2):
#                    print('+ ', end='')
#                else:
#                    print('- ', end='')
#            else:
#                if j in (0, n + 1, 2*n + 2):
#                    print('/ ', end='')
#                else:
#                    print('  ', end='')
#        print('')


def coords(ar1, ar2):
    if distance(ar1, ar2) < 0.2:
        print('near')
    elif distance(ar1, ar2) < 0.5:
        print(' area')


def countdown(n):
    if n <= 0:
        print('Boom!')
    else:
        print(n)
        time.sleep(0.8)
        countdown(n-1)



if __name__ == '__main__':
    conn = pyodbc.connect(
                'DRIVER={SQL Server};'
                'SERVER=RAXEL-ab-sql;'
                'DATABASE=MobileServiceStage;'
                'Trusted_Connection=no;'
                'UID=report;'
                'PWD=report963;'
                )
#    grid(1)
    countdown(4)
#    trip = pd.read_csv(r'E:\Arsen\trip1.csv')
#    print(unique_values(trip, 'AccelerationXOriginal'))
#    df = pd.read_csv(r'E:\Arsen\Driver Signature\data_for_passenger\pass_feat.csv')
#    df_1 = pd.read_csv(r'E:\Arsen\Driver Signature\data_for_passenger\pass_rich.csv')
#    df = pd.read_csv(r'C:\Users\User\Downloads\air.csv', delimiter = '|', encoding='latin1')
#    print(df.head())
